//username: joko190

/*
 * Goal tahun ini:
 * 1. Belajar JavaScript web develop.
 * 2. mahir dalam Back-End Developer.
 */
